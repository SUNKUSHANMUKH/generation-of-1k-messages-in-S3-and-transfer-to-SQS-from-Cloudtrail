const express = require("express");
const bodyParser = require("body-parser");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const app = express();

const dbPath = "/usr/src/app/data/cloudtrail.db";
console.log("🔗 Using DB file:", dbPath);

const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(
    "CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY AUTOINCREMENT, data TEXT)",
    (err) => {
      if (err) {
        console.error("❌ Error creating logs table:", err);
      } else {
        console.log("🔧 Table logs ready!");
      }
    }
  );
});

app.use(bodyParser.json({ limit: "5mb" }));

app.get("/", (req, res) => {
  res.send("CloudTrail log collector is running ✅");
});

app.post("/ingest", (req, res) => {
  console.log("📥 Incoming log record:", req.body);

  if (!req.body || Object.keys(req.body).length === 0) {
    console.warn("⚠️ Empty body received!");
    return res.status(400).send("No Data");
  }

  const jsonString = JSON.stringify(req.body);

  db.run("INSERT INTO logs (data) VALUES (?)", [jsonString], function (err) {
    if (err) {
      console.error("❌ Error inserting log:", err);
      return res.status(500).send("DB Error");
    }

    console.log("💾 Log saved to database! ID =", this.lastID);
    res.status(200).send("OK");
  });
});

const PORT = 8080;
app.listen(PORT, () => {
  console.log(`🚀 App Running on ${PORT}`);
});